from flask import Flask, jsonify, request, render_template

app = Flask(__name__)

# Sample data for brands, categories, genders, and general images
brands = ["BrandA", "BrandB", "BrandC"]
categories = ["T-Shirts", "Jeans", "Jackets"]
genders = ["Male", "Female"]

# Simulated function to generate size chart
def generate_size_chart(brand, category, gender):
    if gender == "Male":
        return {
            "brand": brand,
            "category": category,
            "gender": gender,
            "sizes": {
                "S": {"chest": 36, "waist": 30, "length": 27},
                "M": {"chest": 38, "waist": 32, "length": 28},
                "L": {"chest": 40, "waist": 34, "length": 29},
                "XL": {"chest": 42, "waist": 36, "length": 30},
                "XXL": {"chest": 44, "waist": 38, "length": 31},
                "XXXL": {"chest": 46, "waist": 40, "length": 32},
                "XXXXL": {"chest": 48, "waist": 42, "length": 33},
                "ML": {"chest": 50, "waist": 44, "length": 34},
                "PL": {"chest": 50, "waist": 44, "length": 34},
                "UL": {"chest": 50, "waist": 44, "length": 34},
                "HL": {"chest": 50, "waist": 44, "length": 34},
                "GL": {"chest": 50, "waist": 44, "length": 34},
            }
        }
    else:  # Female
        return {
            "brand": brand,
            "category": category,
            "gender": gender,
            "sizes": {
                "S": {"chest": 34, "waist": 28, "length": 25},
                "M": {"chest": 36, "waist": 30, "length": 26},
                "L": {"chest": 38, "waist": 32, "length": 27},
                "XL": {"chest": 40, "waist": 34, "length": 28},
                "XXL": {"chest": 42, "waist": 36, "length": 29},
                "XXXL": {"chest": 44, "waist": 38, "length": 30},
                "XXXXL": {"chest": 46, "waist": 40, "length": 31},
                "XXXXXL": {"chest": 48, "waist": 42, "length": 32}
            }
        }

# Simulated function to provide a list of general images
def get_general_images():
    # Example image URLs for general display
    return [
        "https://via.placeholder.com/150?text=Image1",
        "https://via.placeholder.com/150?text=Image2",
        "https://via.placeholder.com/150?text=Image3",
        "https://via.placeholder.com/150?text=Image4"
    ]

@app.route('/')
def index():
    return render_template('index.html', brands=brands, categories=categories, genders=genders)

@app.route('/get_size_chart', methods=['POST'])
def get_size_chart():
    data = request.json
    brand = data.get('brand')
    category = data.get('category')
    gender = data.get('gender')
    
    # Generate size chart
    size_chart = generate_size_chart(brand, category, gender)
    return jsonify(size_chart)

@app.route('/get_images', methods=['GET'])
def get_images():
    # Provide general images
    images = get_general_images()
    return jsonify(images)

if __name__ == '__main__':
    app.run(debug=True)
